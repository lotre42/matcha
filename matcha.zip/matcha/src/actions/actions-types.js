export const AT_USERS={
    CREATE: "CREATE_USER",
    CHECK: "CHECK_CONNEXION",
    READ: "READ_USER",
    INFO: "INFO_USER",
    UPDATE: "UPDATE_USER",
}

export const AT_TAG={
    UPDATE: "UPDATE_TAG",
    INFO: "INFO_TAG",
    READ: "READ_TAG",
}

export const AT_IMG={
    UPDATE: "UPDATE_IMG",
    INFO: "INFO_IMG",
    READ: "READ_IMG",
}