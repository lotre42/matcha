# ReactReduxPosts

### Tu as git ? ###

```
> git clone git@github.com:RobinLebhar/ReactMovies.git

```

### Sinon ###

Télécharge le zip ici : https:github.com/RobinLebhar/ReactMovies/archive/master.zip
	
	
### Dans tous les cas : ###
```
	> cd ReactMovies
	> npm start
```
